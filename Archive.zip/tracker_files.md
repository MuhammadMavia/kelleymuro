

# Tracker of workspaces, repositories, etc.

@date: 2015-12-10

# folder-name   template-ionic-stripe-shop-sm
# github:       templ-ionic-stripe-app & templ-ionic-stripe-admin
# c9:           template-ionic-stripe-admin
# firebase:     templ-ionic-stripe
